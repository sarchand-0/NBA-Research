from django.urls import path
from . import views

urlpatterns=[
	path('',views.home, name="home"),
	path('homee/',views.homee, name="homee"),
	path('player/<str:pk>/',views.players, name="players"),
	path('uploadTeam/',views.simple_upload_team, name="uploadTeam"),
	path('uploadPlayer/',views.simple_upload_player, name="uploadPlayer"),
	]