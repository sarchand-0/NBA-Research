from import_export import resources
from .models import *

class TeamResource(resources.ModelResource):
	class meta:
		model = Team
class PlayerResource(resources.ModelResource):
	class meta:
		model = Player