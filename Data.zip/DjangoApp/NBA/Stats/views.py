from django.shortcuts import render
from django.http import HttpResponse
from .models import *
from .resources import TeamResource, PlayerResource
from django.contrib import messages
from tablib import Dataset

def home(request):
    return render(request, 'Stats/home.html')

def players(request,pk):
    player=Player.objects.get(id=pk)
    context={'player':player}
    return render(request, 'Stats/player.html',context)

def Teams(request):
    return render(request, 'Stats/teams.html')

def homee(request):
    teams = Team.objects.all()
    players = Player.objects.filter(Rank__range=(1, 100))
    context = {'teams': teams, 'players': players}
    return render(request, 'Stats/homee.html', context)

def simple_upload_team(request):
    if request.method == 'POST':
        team_resource = TeamResource()
        dataset = Dataset()
        new_team = request.FILES['myfile']

        if not new_team.name.endswith('xlsx'):
            messages.info(request, 'Wrong format, please upload an Excel file.')
            return render(request, 'Stats/uploadTeam.html')

        import_data = dataset.load(new_team.read(), format='xlsx')
        for data in import_data:
            team = Team(
                initials=data[1],
                name=data[2]
            )
            team.save()
        messages.success(request, 'Data imported successfully!')
    return render(request, 'Stats/uploadTeam.html')



def simple_upload_player(request):
    if request.method == 'POST':
        player_resource = PlayerResource()
        dataset = Dataset()
        new_player = request.FILES['myfile']

        if not new_player.name.endswith('xlsx'):
            messages.info(request, 'Wrong format, please upload an Excel file.')
            return render(request, 'Stats/uploadPlayer.html')

        import_data = dataset.load(new_player.read(), format='xlsx')
        for data in import_data:
        	team_initials = data[3]  # Assuming team initials are at index 3
        	team = Team.objects.get(initials=team_initials)
        	player = Player(
           		id=data[0],
                first_name=data[1],
                last_name=data[2],
                team=team,
                Rank=data[5]
            )
        	player.save()
        messages.success(request, 'Data imported successfully!')
    return render(request, 'Stats/uploadPlayer.html')
