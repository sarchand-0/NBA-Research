from django.db import models

class Team(models.Model):
	initials=models.CharField(max_length=200,primary_key=True)
	name = models.CharField(max_length=200,null=True)
	Logo = models.ImageField(default="TeamLogo.png", null=True, blank=True)
	def __str__(self):
		return self.initials
class Player(models.Model):
	id= models.IntegerField(primary_key=True)
	first_name = models.CharField(max_length=200,null=True)
	last_name = models.CharField(max_length=200, null=True)
	team= models.ForeignKey(Team, null=True, on_delete= models.SET_NULL)
	picture = models.ImageField(default="DefaultPlayerImage.png", null=True, blank=True)
	Rank = models.IntegerField(null=True)
	def __str__(self):
		return self.first_name

# Year	Season_type	PLAYER_ID	RANK	PLAYER	TEAM	GP	MIN	FGM	FGA	FG_PCT	FG3M	FG3A	FG3_PCT	FTM	FTA	FT_PCT	OREB	DREB	REB	AST	STL	BLK	TOV	PF	PTS	EFF	AST_TOV	STL_TOV

class Stats(models.Model):
	year = models.CharField(max_length=200,null=True)
